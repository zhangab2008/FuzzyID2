
FuzzyID2 installation:
  X86_64 compile command:
    cp -fr ./include/Bpp /usr/include/
    cp -fr ./lib64/* /usr/lib64/
    g++ main.cpp mainFunction.cpp commonFunction.cpp -o FuzzyID2_X86_64 -lsqlite3 -lbpp-core -lbpp-seq -lbpp-phyl -Wl,-rpath ./lib64
    ln -s FuzzyID2_X86_64 FuzzyID2
  i686 compile command:
    cp -fr ./include/Bpp /usr/include/
    cp -fr ./lib/* /usr/lib/
    g++ main.cpp mainFunction.cpp commonFunction.cpp -o FuzzyID2_i686 -lsqlite3 -lbpp-core -lbpp-seq -lbpp-phyl -Wl,-rpath ./lib
    ln -s FuzzyID2_i686 FuzzyID2

FuzzyID2 execute commands:
    python3 makeDB.py(execute in DB folder)
    ./FuzzyID2 -c Theta1 -m K2P -d AAL123
    ./FuzzyID2 -c Theta2 -m K2P -d AAL123
    ./FuzzyID2 -c MD -in ./test/Noc.fas -m K2P -out ./test/Noc-out.txt -d Noctuidae

For more information, please read the FuzzyID2-guide.pdf. 
