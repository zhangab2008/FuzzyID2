#include "main.h"

void MD(InData *optIn)
{
    //read the query sequences
    Fasta fasReader;
    VectorSequenceContainer *sequences = fasReader.readSequences(optIn->inFile, &AlphabetTools::DNA_ALPHABET);
    int querySequenceNum = sequences->getNumberOfSequences();
    logFile << "The input file has " << querySequenceNum << " query sequences!" << endl;

    for(int i=0;i<querySequenceNum;i++)
    {
        mdResult *mdr;
        mdr = (mdResult *)malloc(sizeof(mdResult));

        outFile << sequences->getSequence(i).getName();
        logFile << sequences->getSequence(i).getName() << endl;
        if(sequences->getSequence(i).toString().length()==0)
        {
            outFile << "\t No sequence!" << endl;
            continue;
        }
        Sequence *seqQuery = new BasicSequence(sequences->getName(i),sequences->getSequence(i).toString(),&AlphabetTools::DNA_ALPHABET);

        //calculate order,family,genus,species MD and get the theta1,theta2
		sprintf(mdr->model,"%s",optIn->model);
		sprintf(mdr->dataBase,"%s",optIn->dataBase);

		//get MD,theta1,theta2
        int flag = getMD(seqQuery, mdr);
        if(flag == 2)//doesn't found the MD sequence
        {
            outFile << "\t" << mdr->roughGenus << " No appropriate data in the database" << endl;
            continue;
        }
        else if(flag == 3)
        {
            outFile << "\t The query sequence is too far from the reference data!" << endl;
            continue;
        }
		//get FMF score
        outFile << "\t" << mdr->taxoName;
        outFile << "\t" <<"FMF:" << calMF(mdr->md,mdr->theta1,mdr->theta2);
		outFile << "\t" <<"MD:" << mdr->md;
		outFile << "\t" <<"Theta1:" << mdr->theta1;
		outFile << "\t" <<"Theta2:" << mdr->theta2 << endl;
    }//for,loop query sequences
}

//Theta1
void Theta1(InData *optIn)
{
    theta1Result *t1r;
    t1r = (theta1Result *)malloc(sizeof(theta1Result));

    logFile << ">getTheta1function start " << endl;
    //get the sequences existing in db
	sprintf(t1r->model,"%s",optIn->model);
    getTheta1function(t1r);
}

//Theta2
void Theta2(InData *optIn)
{
    theta2Result *t2r;
    t2r = (theta2Result *)malloc(sizeof(theta2Result));
    logFile << ">getTheta2function start " << endl;

    //get the sequences existing in db
	sprintf(t2r->model,"%s",optIn->model);
    int flag = getTheta2function(t2r);
}
