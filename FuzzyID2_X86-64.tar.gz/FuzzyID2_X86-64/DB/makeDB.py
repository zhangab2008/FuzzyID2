# -*- coding: utf8 -*-
#soft:boldtsv2fas2db
#version:1.0
#author:zhiyong-shi
#email:zhiyong-shi@163.com
#date:2014.11.05
#descripe:convert bold tsv format to fasta format and save sequences in DB
#example:python boldtsv2fas2db.py
#version:v1.0_2014.12.05_convert bold tsv format to fasta format, save fasta data to DB
#        v2.0_2015.03.10_add hmm function,save data(table Rough) as hmm profile
        

import time
import sys
import re
import sqlite3
import os

#define globle parameters###########################################################################
#set barcode marker
refMarker="COI-5P"
#set max and min length of DNA sequence in the reference database
Max_length_DNA=1000
Min_length_DNA=300
#set barcodes number from each species to form the rough scan database, based on the reference datasets scale
roughDataNum="5"

#codeCheck##########################################################################################
#check sequence DNA alphabet
def codeCheck(sequence):
    DNA="ATGCUMRWSYKVHDBN-"
    for i in range(0,len(sequence)):
        if sequence[i] not in DNA:
            return 1
    return 0

#tsv2fas############################################################################################
#get sequence from tsv file
def tsv2fas(fileName):
    #open files
    try:
        fi=open(fileName,"r") # Opens file for reading
        fo=open(fileName.split('.')[0]+".fas","w")
        fe=open(fileName.split('.')[0]+".info","w")
    except IOError as e:
        print("file open error:"+str(e))
        end = input("press any key to exit.")
        exit(1)

    fe.write("****************************************************\n")
    fe.write("tsv2fas function error:")
    fe.write("DNA code check error: please check the DNA sequence!\n")
    fe.write("Data error: please check whether marker is not refMarker, DNA length is less than 500bp, Genus name is not given!\n")
    fe.write("****************************************************\n\n")

    #read file per line
    for line in fi:
        taxo={}
        item=line.split('\t')
        taxo['SequenceID']=item[0].strip()
        taxo['Family']=item[14].strip()
        taxo['Genus']=item[18].strip()
        taxo['Species']=item[20].strip()
        taxo['Marker']=item[40].strip()
        taxo['DNA']=item[42].strip().replace("-","").replace("N","")
        if len(taxo['DNA'])>Max_length_DNA:
            taxo['DNA']=taxo['DNA'][0:Max_length_DNA]

        if codeCheck(taxo['DNA'])==1:
            fe.write("DNA alphabet check error! processid:"+taxo['SequenceID']+"\n")
            continue

        if re.match('^[0-9A-Z-]+$',taxo['SequenceID']):#code check
            if taxo['Marker']==refMarker and len(taxo['DNA'])>Min_length_DNA and len(taxo['Family'])>0 and len(taxo['Genus'])>0:#sequence quality filter
                #write data to file
                fo.write(">"+taxo['SequenceID']+"_"+taxo['Family']+"_"+taxo['Genus']+"_"+taxo['Species']+"\n")
                fo.write(taxo['DNA']+"\n")
            else:
                fe.write("Data error! processid:"+taxo['SequenceID']+"\n")
    #close file
    fi.close()
    fo.close()
    fe.close()

#seqInOne#############################################################################################
#convert multiple sequence line in one for fasta file
def seqInOne(fileName):
    #open files
    try:
        fi=open(fileName,"r")
        fo=open(fileName.split('.')[0]+".one.fas","w")
    except IOError as e:
        print("file open error:"+str(e))
        end = input("press any key to exit.")
        exit(1)

    flag=0
    for line in fi:
        if line.startswith('>'):
            fo.write("\n"+line)
            flag=1
        else:
            if flag==1:
                fo.write(line.strip())
    fo.write("\n")
    fi.close()
    fo.close()

    try:
        fi=open(fileName.split('.')[0]+".one.fas","r")
        fo=open(fileName,"w")
    except IOError as e:
        print("file open error:"+str(e))
        end = input("press any key to exit.")
        exit(1)
    a=fi.readlines()
    b=''.join(a[1:])
    fo.write(b)
    fi.close()
    fo.close()

    command = "rm -f "+fileName.split('.')[0]+".one.fas"
    os.system(command)

#deleteRepeat#############################################################################################
#deal with Haplotype sequences
def deleteRepeat(fileName):
    #open files
    try:
        fi=open(fileName,"r")
        fo=open(fileName.split('.')[0]+".out.fas","w")
        fs=open(fileName.split('.')[0]+".sum.txt","w")
    except IOError as e:
        print("file open error:"+str(e))
        end = input("press any key to exit.")
        exit(1)

    dictDNA={}#Dictionary with sequence as key and comment as value
    flag=0
    key=""
    value=""
    for line in fi:
        if len(line.strip())==0:
            continue
        if line.startswith('>'):
            value=line.strip()
            flag=0
        else:
            key=line.strip()
            flag=1
        if flag==1:
            if key in dictDNA:#add new Haplotype into Dict 
                tmp=dictDNA[key]+"|"+value
                dictDNA[key]=tmp
            else:
                dictDNA[key]=value
    for key in dictDNA:
        fo.write(dictDNA[key].split('|')[0]+"\n")
        fo.write(key+"\n")
        fs.write(dictDNA[key]+"\n")

    fi.close()
    fo.close()
    fs.close()

    command = "mv -f "+fileName.split('.')[0]+".out.fas "+fileName
    os.system(command)

#fas2db#############################################################################################
#save data in database
def fas2db(fileName):
    #open file and database
    if os.path.exists(fileName.split('.')[0]+".error"):
        fe=open(fileName.split('.')[0]+".error","a")
    else:
        fe=open(fileName.split('.')[0]+".error","w")
    try:
        fi=open(fileName,"r") # Opens file for reading
        conn = sqlite3.connect(fileName.split('.')[0])#connect database
        cur = conn.cursor()#create cursor
    except IOError as e:
        print("file open error:"+str(e))
        end = input("press any key to exit.")
        exit(1)
        
    conn.isolation_level = None
    fe.write("****************************************************\n")
    fe.write("fas2db function error:")
    fe.write("DNA code check error: please check the DNA sequence!\n")
    fe.write("****************************************************\n\n")

    ###########################################################
    #create Item table
    command=("CREATE TABLE if not exists Item("
        "recordID integer primary key autoincrement,"
        "sequenceID varchar(50) NOT NULL,"
        "nucleotides varchar(1200) NOT NULL,"
        "theta1_species double(10,8) DEFAULT 2,"
        "theta2_species double(10,8) DEFAULT 2,"
        "family_name varchar(50) NOT NULL,"
        "genus_name varchar(50) NOT NULL,"
        "species_name varchar(50) NOT NULL)")
    cur.execute(command)
    #create Rough table
    command=("CREATE TABLE if not exists Rough("
        "recordID integer primary key autoincrement,"
        "sequenceID varchar(50) NOT NULL,"
        "nucleotides varchar(1200) NOT NULL,"
        "family_name varchar(50) NOT NULL,"
        "genus_name varchar(50) NOT NULL,"
        "species_name varchar(50) NOT NULL)")
    cur.execute(command)
    conn.commit()
    ###############################################################
    #read fasta file and save data in database
    cmdItem=""

    taxo={}
    flag=0
    for line in fi:
        if line.startswith('>'):
            item=line.split('>')[1].split('_')
            taxo['SequenceID']=item[0].strip()
            taxo['Family']=item[1].strip()
            taxo['Genus']=item[2].strip()
            taxo['Species']=item[3].strip()

            if len(taxo['Genus'])==0 or len(taxo['Species'])==0:
                flag=0
                continue
            #insert data in Item table
            cmdItem=("insert into Item("
                "SequenceID,nucleotides,family_name,genus_name,species_name)"
                "values('"+taxo['SequenceID']+"','nucleotides_replace','"+taxo['Family']+"','"+taxo['Genus']+"','"+taxo['Species']+"')")
            flag=1
        else:
            if flag==1:
                #add DNA check
                sequence=line.strip().replace("-","").replace("N","")
                if len(sequence)>Max_length_DNA:
                    sequence=sequence[0:Max_length_DNA]
                if len(sequence)<Min_length_DNA:
                    cmdItem=""
                    sequence=""
                    flag=0
                    continue

                if codeCheck(sequence)==1:
                    fe.write("DNA code check error! SequenceID:"+taxo['SequenceID']+"\n")
                    cmdItem=""
                    sequence=""
                    flag=0
                    continue
                cmdItem=cmdItem.replace("nucleotides_replace",sequence)
                cur.execute(cmdItem)
                cmdItem=""
                sequence=""
                flag=0
    conn.commit()
    
    #################################################################
    #Fetch data randomly from Item table and insert into Rough table#
    familySql="select family_name from Item group by family_name"
    cur.execute(familySql)
    resFamily = cur.fetchall()
    for family_name in resFamily:
        selectSql="select species_name from Item where family_name='"+family_name[0]+"' group by species_name"
        cur.execute(selectSql)
        resSpecies = cur.fetchall()
        for species_name in resSpecies:
            insertRough=("insert into Rough"
                     "(sequenceID,nucleotides,family_name,genus_name,species_name) "
                     "select sequenceID,nucleotides,family_name,genus_name,species_name "
                     "from Item where family_name='"+family_name[0]+"' and species_name='"+str(species_name[0])+"' order by RANDOM() limit "+roughDataNum)
            cur.execute(insertRough)
        conn.commit()

    #close file and db
    fi.close()
    cur.close()
    conn.close()
#makeHmm###########################################################################################
#Fetch data from Rough table and convert to hmm data format
def makeHmm(fileName):
    #connect database
    dbName=fileName.split('.')[0]
    try:
        conn = sqlite3.connect(dbName)
        cursor = conn.cursor()
    except IOError as e:
        print("database open error:"+str(e))
        end = input("press any key to exit.")
        exit(1)
    conn.isolation_level = None
    ###########################################################
    sqlstr = "select sequenceID,family_name,genus_name,nucleotides from Rough order by sequenceID"
    head = "# STOCKHOLM 1.0\r\n"

    n = cursor.execute(sqlstr)
    for row in cursor.fetchall():
        fo=open("../HmmDB/"+str(row[0])+"_"+str(row[1])+"_"+str(row[2])+".fasta","w")
        fo.write(head)
        fo.write(str(row[0])+"_"+str(row[1])+"_"+str(row[2])+" "+str(row[3])+"\r\n"+"//\r\n")
        fo.close()
        hmmpath = "../bin"
        ifile = "../HmmDB/" + str(row[0])+"_"+str(row[1])+"_"+str(row[2]) + ".fasta"
        ofile = "../HmmDB/" + str(row[0])+"_"+str(row[1])+"_"+str(row[2]) + ".hmm"
        hmmcommand = hmmpath + "/hmmbuild " + ofile + " " + ifile
        os.system(hmmcommand)

    #hmmcommand = "cat " + "../HmmDB/*.hmm > " + "../HmmDB/"+dbName
    hmmcommand = "find ../HmmDB -type f -name \"*.hmm\"|xargs cat > ../HmmDB/"+dbName
    os.system(hmmcommand)
    hmmcommand = hmmpath + "/hmmpress " + "../HmmDB/"+dbName
    os.system(hmmcommand)
    #hmmcommand="rm -fr ../HmmDB/*.fasta"
    hmmcommand = "find ../HmmDB -type f -name \"*.fasta\"|xargs rm -f"
    os.system(hmmcommand)
    #hmmcommand="rm -fr ../HmmDB/*.hmm"
    hmmcommand = "find ../HmmDB -type f -name \"*.hmm\"|xargs rm -f"
    os.system(hmmcommand)

    #close db
    conn.close()
#main#############################################################################################
if __name__ == '__main__':
    #main
    print("bold tsv 2 fasta format convert start.")
    print("Any problems, please email me.[zhiyong-shi@163.com]")
    #process start time
    timeb=time.strftime('%H%M%S', time.localtime(time.time()))
    print("Process start at "+timeb)
    print("-"*60)

    #input
    print("Processing method:")
    print("1:input bold tsv file, convert it to fasta file, and then save the data to DB!")
    print("2:input fasta file, and then save the data in DB!")
    method=input("Please select the method:")
    if method=='1':
        fileName = input("Please input bold tsv file:")
        print("Processing bold_tsv2fas start.........")
        tsv2fas(fileName)
        print("Processing fas2db start.........")
        seqInOne(fileName.split('.')[0]+".fas")
        deleteRepeat(fileName.split('.')[0]+".fas")
        fas2db(fileName.split('.')[0]+".fas")
        print("Processing makeHmm start........")
        makeHmm(fileName)
    elif method=='2':
        fileName = input("Please input fasta file:")
        print("Processing fas2db start.........")
        seqInOne(fileName)
        deleteRepeat(fileName.split('.')[0]+".fas")
        fas2db(fileName)
        print("Processing makeHmm start........")
        makeHmm(fileName)
    else:
        print("Please select correct method! 1 or 2!")

    #process end time
    print("-"*60)
    timee=time.strftime('%H%M%S', time.localtime(time.time()))
    print("Process end at "+timee)
    end = input("press any key to exit.")
