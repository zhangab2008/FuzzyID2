#!/usr/bin/env python
#encoding: utf-8
"""
approach:FuzzyID2_makeDB.py
version:1.0
author:zhiyong shi
email:zhiyong-shi@163.com
descripe:FuzzyID2_makeDB.py is the init approach of FuzzyID2 pipline. This approach converts bold tsv format to fasta format and save sequences in DB, and then form rough scan database.
date:2017.2.6

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
The following restriction to the GNU GPL applies: contact the author of this program (http://willpearse.github.com/phyloGenerator) for a suitable citation when publishing work that uses this code.
This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
You should have received a copy of the GNU General Public License along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

import time
import sys
import re
import sqlite3
import os
import platform

LOGFILE="makeDB.log"
#codeCheck######################################################################
#check sequence DNA alphabet
def codeCheck(sequence):
    DNA="atgcumrwsykvhdbnATGCUMRWSYKVHDBN-"
    for i in range(0,len(sequence)):
        if sequence[i] not in DNA:
            return 1
    return 0

#seqIdRepeatCheck###############################################################
#seqID should be without repetition
def seqIdRepeatCheck(refFile):
    flog=open(LOGFILE,"a")
    flog.write("#"*50+"\n")
    flog.write("#function seqIdRepeatCheck start.\n")

    if ".tsv" in refFile:
        fileName="./tmp/"+refFile.split("/")[-1].split('.')[0]+".fasta"
    else:
        fileName=refFile
    try:
        fi=open(fileName,"r")
    except IOError as e:
        print("file open error:"+str(e))
        exit(1)

    seqIDs=[]
    flag=0
    for line in fi:
        if line.startswith('>'):
            seqID=line.split('>')[1].split('_')[0]
            if seqID in seqIDs:
                flog.write(seqID+" is repeat, please check...\n")
                flag=1
            else:
                seqIDs.append(seqID)
    fi.close()
    flog.close()

    if flag==1:
        print("sequence ID repeat check error! Please view log.txt for details. Exiting...")
        sys.exit(1)

#seqInOne#######################################################################
#convert multiple sequence line in one for fasta file
def seqInOne(refFile):
    flog=open(LOGFILE,"a")
    flog.write("#"*50+"\n")
    flog.write("#function seqInOne start.\n")

    if ".tsv" in refFile:
        fileName="./tmp/"+refFile.split("/")[-1].split('.')[0]+".fasta"
    else:
        fileName=refFile
    #open files
    try:
        fi=open(fileName,"r")
        fo=open("./tmp/"+fileName.split("/")[-1].split('.')[0]+".one.fasta","w")
    except IOError as e:
        print("file open error:"+str(e))
        exit(1)

    flag=0
    for line in fi:
        if line.startswith('>'):
            fo.write("\n"+line)
            flag=1
        else:
            if flag==1:
                fo.write(line.strip())
    fo.write("\n")
    fi.close()
    fo.close()

    try:
        fi=open("./tmp/"+fileName.split("/")[-1].split('.')[0]+".one.fasta","r")
        fo=open("./tmp/"+fileName.split("/")[-1],"w")
    except IOError as e:
        print("file open error:"+str(e))
        exit(1)
    a=fi.readlines()
    b=''.join(a[1:])
    fo.write(b)
    fi.close()
    fo.close()

    command = "rm -f ./tmp/"+fileName.split("/")[-1].split('.')[0]+".one.fasta"
    ret=os.system(command)
    if ret==0:
        pass
    else:
        print("Error:ret="+str(ret)+",command="+command)
        sys.exit(1)

#tsv2fasta########################################################################
#get sequence from tsv file
def tsv2fasta(refFile,paraList):
    """
    Reference dataset tsv format file can be downloaded from BOLD system.
    Function tsv2fasta extract target fields from tsv file and save them as fasta format. Fasta format: >SequenceID_Family_Genus_Species
    Output fasta file example:
    >GBCH3233-09_Araneidae_Verrucosa_Verrucosa arenata
    ACTTTATATTTGATTTTTGGAGCTTGGGCTGCTATAGTAGGAACTGCAATAAGAGT...
    """
    flog=open(LOGFILE,"a")
    flog.write("#"*50+"\n")
    flog.write("#function tsv2fasta start.\n")

    #open files
    if ".tsv" in refFile:
        fileName=refFile
    else:
        print("Reference dataset file format error, should be tsv format! Exiting...")
        sys.exit(1)
    try:
        fi=open(fileName,"r") # Opens file for reading
        fo=open("./tmp/"+fileName.split("/")[-1].split('.')[0]+".fasta","w")
    except IOError as e:
        print("file open error:"+str(e))
        sys.exit(1)

    piNo, familyNo, genusNo, speciesNo, markerNo, giNo, dnaNo=0,0,0,0,0,0,0
    #read file per line
    for line in fi:
        if line.startswith('processid'):
            fields=line.split('\t')
            i=0
            for field in fields:
                if field.strip()=="processid":
                    piNo=i
                elif field.strip()=="family_name":
                    familyNo=i
                elif field.strip()=="genus_name":
                    genusNo=i
                elif field.strip()=="species_name":
                    speciesNo=i
                elif field.strip()=="markercode":
                    markerNo=i
                elif field.strip()=="genbank_accession":
                    giNo=i
                elif field.strip()=="nucleotides":
                    dnaNo=i
                i=i+1
            continue
        taxo={}
        item=line.split('\t')
        if len(item[giNo])!=0:
            taxo['SequenceID']=item[giNo].strip()
        else:
            taxo['SequenceID']=item[piNo].strip()
        taxo['Family']=item[familyNo].strip()
        taxo['Genus']=item[genusNo].strip()
        taxo['Species']=item[speciesNo].strip()
        if len(taxo['Species'])==0 or "sp." in taxo['Species']:
            taxo['Species']=taxo['Genus']+" unknown"
        taxo['Marker']=item[markerNo].strip()

        if re.match(r'^[0-9A-Za-z-_.]+$',taxo['SequenceID']):
            pass
        else:
            flog.write("sequenceID should be letters, numbers and '-', '_', '.'. sequenceID:"+taxo['SequenceID']+"\n")
            continue
        if taxo['Marker'].upper() in paraList["refMarker"].upper():
            pass
        else:
            flog.write("sequence marker is not contained in the marker list. sequenceID:"+taxo['SequenceID']+"\n")
            continue
        #sequence quality filter
        if paraList["seqClean"]=="on":
            taxo['DNA']=item[dnaNo].strip().replace("-","").replace("N","")
            if len(taxo['DNA'])>int(paraList["Max_length_DNA"]):
                taxo['DNA']=taxo['DNA'][0:int(paraList["Max_length_DNA"])]
                flog.write("Sequence length:"+str(len(taxo['DNA']))+" > Max_length_DNA, has been cut. sequenceID:"+taxo['SequenceID']+"\n")

            if codeCheck(taxo['DNA'])==1:#code check
                flog.write("DNA alphabet check error! sequenceID:"+taxo['SequenceID']+"\n")
                continue

            if len(taxo['DNA'])>int(paraList["Min_length_DNA"]):
                pass
            else:
                flog.write("sequence removed, DNA length < "+paraList["Min_length_DNA"]+". sequenceID:"+taxo['SequenceID']+"\n")
                continue
            if len(taxo['Family'])>0 and len(taxo['Genus'])>0 and len(taxo['Species'])>0:
                pass
            else:
                flog.write("sequence taxo must contain family name and genus name. sequenceID:"+taxo['SequenceID']+"\n")
                continue

        #write data to file
        fo.write(">"+taxo['SequenceID']+"_"+taxo['Family']+"_"+taxo['Genus']+"_"+taxo['Species']+"\n")
        fo.write(taxo['DNA']+"\n")

    #close file
    fi.close()
    fo.close()
    flog.close()

#deleteRepeatSeq################################################################
#deal with Haplotype sequences
def deleteRepeatSeq(refFile):
    """
    Function deleteRepeatSeq delete haplotype sequences and reserve two.
    """
    flog=open(LOGFILE,"a")
    flog.write("#"*50+"\n")
    flog.write("#function deleteRepeatSeq start.\n")

    #open files
    if ".tsv" in refFile:
        fileName="./tmp/"+refFile.split("/")[-1].split('.')[0]+".fasta"
    else:
        fileName="./tmp/"+refFile.split('/')[-1]
    try:
        fi=open(fileName,"r")
        fo=open("./tmp/"+fileName.split('/')[-1].split('.')[0]+".out.fasta","w")
        fs=open("./tmp/"+fileName.split('/')[-1].split('.')[0]+".sum.txt","w")
    except IOError as e:
        print("file open error:"+str(e))
        sys.exit(1)

    dictDNA={}#Dictionary with sequence as key and comment as value
    flag=0
    key=""
    value=""
    for line in fi:
        if len(line.strip())==0:
            continue
        if line.startswith('>'):
            value=line.strip()
            flag=0
        else:
            key=line.strip()
            flag=1
        if flag==1:
            if key in dictDNA:#add new Haplotype into Dict 
                tmp=dictDNA[key]+"|"+value
                dictDNA[key]=tmp
            else:
                dictDNA[key]=value
    for key in dictDNA:
        fo.write(dictDNA[key].split('|')[0]+"\n")
        fo.write(key+"\n")
        if '|' in dictDNA[key]:#reserve haplotype sequence two if it has
            fo.write(dictDNA[key].split('|')[1]+"\n")
            fo.write(key+"\n")

        fs.write(dictDNA[key]+"\n")

    fi.close()
    fo.close()
    fs.close()

    command = "mv -f ./tmp/"+fileName.split('/')[-1].split('.')[0]+".out.fasta ./tmp"+fileName.split('/')[-1]
    ret=os.system(command)
    if ret==0:
        pass
    else:
        print("Error:ret="+str(ret)+",command="+command)
        sys.exit(1)
    flog.close()

#fasta2db#########################################################################
#save data in database
def fasta2db(refFile,paraList):
    """
    Function fasta2db extract fields from fasta file and save them in database. Fasta format: >SequenceID_Family_Genus_Species
    fasta file example:
    >GBCH3233-09_Araneidae_Verrucosa_Verrucosa arenata
    ACTTTATATTTGATTTTTGGAGCTTGGGCTGCTATAGTAGGAACTGCAATAAGAGT...
    """
    flog=open(LOGFILE,"a")
    flog.write("#"*50+"\n")
    flog.write("#function fasta2db start.\n")

    #open file and database
    if ".tsv" in refFile:
        fileName="./tmp/"+refFile.split("/")[-1].split('.')[0]+".fasta"
    else:
        fileName="./tmp/"+refFile.split("/")[-1]

    try:
        fi=open(fileName,"r") # Opens file for reading
        conn = sqlite3.connect("./DB/"+paraList["refDBName"])#connect database
        cur = conn.cursor()#create cursor
    except IOError as e:
        print("file open error:"+str(e))
        sys.exit(1)

    #conn.isolation_level = None

    #######################################################
    #create Item table
    command=("CREATE TABLE if not exists Item("
        "recordID integer primary key autoincrement,"
        "sequenceID varchar(50) NOT NULL,"
        "nucleotides varchar(1200) NOT NULL,"
        "marker varchar(50) NOT NULL,"
        "theta1_species double(10,8) DEFAULT 2,"
        "theta2_species double(10,8) DEFAULT 2,"
        "family_name varchar(50) NOT NULL,"
        "genus_name varchar(50) NOT NULL,"
        "species_name varchar(50) NOT NULL)")
    cur.execute(command)
    #create Rough table
    command=("CREATE TABLE if not exists Rough("
        "recordID integer primary key autoincrement,"
        "sequenceID varchar(50) NOT NULL,"
        "nucleotides varchar(1200) NOT NULL,"
        "marker varchar(50) NOT NULL,"
        "family_name varchar(50) NOT NULL,"
        "genus_name varchar(50) NOT NULL,"
        "species_name varchar(50) NOT NULL)")
    cur.execute(command)
    conn.commit()
    #######################################################
    #read fasta file and save data in database

    refMarker=""
    for marker in paraList["refMarker"].split("|"):
        if marker.upper() in refFile.upper():
            refMarker=marker.strip().upper()
            break

    cmdItem=""
    taxo={}
    flag=0
    sql_lines=[]
    for line in fi:
        if line.startswith('>'):
            try:
                item=line.split('>')[1].split('_')
                taxo['SequenceID']=item[0].strip()
                taxo['Family']=re.sub('[\'\"\,\.\(\)\;]','',item[1].strip())
                taxo['Genus']=re.sub('[\'\,\"\.\(\)\;]','',item[2].strip())
                taxo['Species']=re.sub('[\'\"\,\.\(\)\;]','',item[3].strip())
            except:
                print("Sequence comment should be in format: >SequenceID_Family_Genus_Species! seq:"+line)

            if len(taxo['Species'])==0 or "sp." in taxo['Species']:
                taxo['Species']=taxo['Genus']+" unknown"
            if re.match(r'^[0-9A-Za-z-_.]+$',taxo['SequenceID']):
                pass
            else:
                flog.write("sequenceID should be letters, numbers and '-', '_', '.'. sequenceID:"+taxo['SequenceID']+"\n")
                continue
            if len(taxo['Family'])==0 or len(taxo['Genus'])==0 or len(taxo['Species'])==0:
                flag=0
                flog.write("sequence taxo must contain family name, genus name. sequenceID:"+taxo['SequenceID']+"\n")
                continue
            #insert data in Item table
            cmdItem=("insert into Item("
                "SequenceID,nucleotides,marker,family_name,genus_name,species_name)"
                "values('"+taxo['SequenceID']+"','nucleotides_replace','"+refMarker+"','"+taxo['Family']+"','"+taxo['Genus']+"','"+taxo['Species']+"');")
            flag=1
        else:
            if flag==1:
                #add DNA check
                if paraList["seqClean"]=="on":
                    sequence=line.strip().replace("-","").replace("N","")
                    if len(sequence)>int(paraList["Max_length_DNA"]):
                        sequence=sequence[0:int(paraList["Max_length_DNA"])]
                    if len(sequence)<int(paraList["Min_length_DNA"]):
                        cmdItem=""
                        sequence=""
                        flag=0
                        flog.write("sequence removed, DNA length < "+paraList["Min_length_DNA"]+". sequenceID:"+taxo['SequenceID']+"\n")
                        continue

                    if codeCheck(sequence)==1:
                        cmdItem=""
                        sequence=""
                        flag=0
                        flog.write("DNA alphabet check error! sequenceID:"+taxo['SequenceID']+"\n")
                        continue
                cmdItem=cmdItem.replace("nucleotides_replace",sequence)
                sql_lines.append(cmdItem)
                cmdItem=""
                sequence=""
                flag=0

    for sql in sql_lines:
        cur.execute(sql)
    conn.commit()

    #close file and db
    fi.close()
    cur.close()
    conn.close()
    flog.close()

#createDBIndex##################################################################
#create index on the search column of the reference database
def createDBIndex(paraList):
    """
    create index on the search column of the reference database.
    """
    flog=open(LOGFILE,"a")
    flog.write("#"*50+"\n")
    flog.write("#function createDBIndex start.\n")

    #connect database
    try:
        conn = sqlite3.connect("./DB/"+paraList["refDBName"])
        cur = conn.cursor()
    except IOError as e:
        print("database open error:"+str(e))
        sys.exit(1)
    #conn.isolation_level = None

    flog.write("Create index on field family_name, genus_name, species_name and marker.\n")
    sql="CREATE INDEX Item_family on Item(family_name)"
    cur.execute(sql)
    sql="CREATE INDEX Item_marker on Item(marker)"
    cur.execute(sql)
    sql="CREATE INDEX Item_genus on Item(genus_name)"
    cur.execute(sql)
    sql="CREATE INDEX Item_species on Item(species_name)"
    cur.execute(sql)
    conn.commit()

    cur.close()
    conn.close()
    flog.close()

#makeHmmDB########################################################################
#Fetch data from Rough table and convert to hmm data format
def makeHmmDB(paraList,refRoughMarker):
    """
    Function makeHmmDB fetch data from Rough table and convert to hmm data format.
    """
    flog=open(LOGFILE,"a")
    flog.write("#"*50+"\n")
    flog.write("#function makeHmmDB start.\n")

    #connect database
    try:
        conn = sqlite3.connect("./DB/"+paraList["refDBName"])
        cur = conn.cursor()
    except IOError as e:
        print("database open error:"+str(e))
        sys.exit(1)
    #conn.isolation_level = None

    #######################################################
    #Fetch data randomly from Item table and insert into Rough table
    #cur.execute("BEGIN TRANSACTION")
    flog.write("Fetch data randomly from Item table and insert into Rough table.\n")
    sql_lines=[]
    genusSql="select genus_name from Item where marker='"+refRoughMarker.upper()+"' group by genus_name"
    cur.execute(genusSql)
    resGenus = cur.fetchall()
    for genus_name in resGenus:
        speciesSql="select species_name from Item where genus_name='"+genus_name[0]+"' and marker='"+refRoughMarker.upper()+"' group by species_name"
        cur.execute(speciesSql)
        resSpecies = cur.fetchall()
        for species_name in resSpecies:
            countSql="select count(*) from Item where species_name='"+species_name[0]+"' and marker='"+refRoughMarker.upper()+"'"
            cur.execute(countSql)
            resSeq=cur.fetchone()
            seqNum=int(resSeq[0])
            if float(paraList["roughPercent"])>0.99:
                roughNum=seqNum
            else:
                if seqNum<int(paraList["roughMinNum"]):
                    roughNum=seqNum
                elif seqNum*float(paraList["roughPercent"])<int(paraList["roughMinNum"]):
                    roughNum=int(paraList["roughMinNum"])
                elif seqNum*float(paraList["roughPercent"])>int(paraList["roughMaxNum"]):
                    roughNum=int(paraList["roughMaxNum"])
                else:
                    roughNum=int(seqNum*float(paraList["roughPercent"]))
            insertRough=("insert into Rough"
                     "(sequenceID,nucleotides,marker,family_name,genus_name,species_name) "
                     "select sequenceID,nucleotides,marker,family_name,genus_name,species_name "
                     "from Item where marker='"+refRoughMarker.upper()+"' and genus_name='"+str(genus_name[0])+"' and species_name='"+str(species_name[0])+"' order by RANDOM() limit "+str(roughNum))
            #print(insertRough)
            sql_lines.append(insertRough)
    #flog.write('\r\n'.join(sql_lines))
    for sql in sql_lines:
        cur.execute(sql)
    conn.commit()
    #cur.execute("COMMIT")

    #######################################################
    #Make HmmDB using rough table data#
    flog.write("Make HmmDB using rough table data.\n")
    sqlstr = "select sequenceID,family_name,genus_name,marker,nucleotides from Rough where marker='"+refRoughMarker.upper()+"' order by sequenceID"
    head = "# STOCKHOLM 1.0\r\n"

    hmmpath = "./bin/"
    hmmbuild="hmmbuild"
    if platform.uname().processor=="x86_64":
        hmmbuild=hmmbuild+"_x86_64"
    elif platform.uname().processor=="i386":
        hmmbuild=hmmbuild+"_i386"

    n = cur.execute(sqlstr)
    for row in cur.fetchall():
        fo=open("./HmmDB/"+str(row[0])+"_"+str(row[1])+"_"+str(row[2])+"_"+str(row[3])+".fasta","w")
        fo.write(head)
        fo.write(str(row[0])+"_"+str(row[1])+"_"+str(row[2])+"_"+str(row[3])+" "+str(row[4])+"\r\n"+"//\r\n")
        fo.close()

        ifile = "./HmmDB/" + str(row[0])+"_"+str(row[1])+"_"+str(row[2])+"_"+str(row[3]) + ".fasta"
        ofile = "./HmmDB/" + str(row[0])+"_"+str(row[1])+"_"+str(row[2])+"_"+str(row[3]) + ".hmm"
        hmmcommand = hmmpath + hmmbuild + " --dna " + ofile + " " + ifile
        ret=os.system(hmmcommand)
        if ret==0:
            pass
        else:
            print("Error:ret="+str(ret)+",command="+hmmcommand)
            sys.exit(1)

    #close db
    cur.close()
    conn.close()
    flog.close()

################################################################################
def HmmDBPress(paraList):
    hmmpath = "./bin/"
    hmmpress="hmmpress"
    if platform.uname().processor=="x86_64":
        hmmpress=hmmpress+"_x86_64"
    elif platform.uname().processor=="i386":
        hmmpress=hmmpress+"_i386"

    hmmcommand = "find ./HmmDB -type f -name \"*.hmm\"|xargs cat > ./HmmDB/"+paraList["refDBName"]
    ret=os.system(hmmcommand)
    if ret==0:
        pass
    else:
        print("Error:ret="+str(ret)+",command="+hmmcommand)
        sys.exit(1)
    hmmcommand = hmmpath + hmmpress + " " + "./HmmDB/"+paraList["refDBName"]
    ret=os.system(hmmcommand)
    if ret==0:
        pass
    else:
        print("Error:ret="+str(ret)+",command="+hmmcommand)
        sys.exit(1)
    #hmmcommand="rm -fr ./HmmDB/*.fasta"
    hmmcommand = "find ./HmmDB -type f -name \"*.fasta\"|xargs rm -f"
    ret=os.system(hmmcommand)
    if ret==0:
        pass
    else:
        print("Error:ret="+str(ret)+",command="+hmmcommand)
        sys.exit(1)
    #hmmcommand="rm -fr ./HmmDB/*.hmm"
    hmmcommand = "find ./HmmDB -type f -name \"*.hmm\"|xargs rm -f"
    ret=os.system(hmmcommand)
    if ret==0:
        pass
    else:
        print("Error:ret="+str(ret)+",command="+hmmcommand)
        sys.exit(1)

################################################################################
def rmPreDB(paraList):
    """
    rm previous data in ./DB and ./HmmDB folder
    """
    if os.path.exists("./DB/"+paraList["refDBName"]):
        command = "rm -f ./DB/"+paraList["refDBName"]
        ret=os.system(command)
        if ret==0:
            pass
        else:
            print("Error:ret="+str(ret)+",command="+command)
            sys.exit(1)

    command = "rm -f ./HmmDB/"+paraList["refDBName"]
    ret=os.system(command)
    command = "rm -f ./HmmDB/"+paraList["refDBName"]+".h3*"
    ret=os.system(command)
    #hmmcommand="rm -fr ./HmmDB/*.fasta"
    hmmcommand = "find ./HmmDB -type f -name \"*.fasta\"|xargs rm -f"
    ret=os.system(hmmcommand)
    if ret==0:
        pass
    else:
        print("Error:ret="+str(ret)+",command="+hmmcommand)
        sys.exit(1)
    #hmmcommand="rm -fr ./HmmDB/*.hmm"
    hmmcommand = "find ./HmmDB -type f -name \"*.hmm\"|xargs rm -f"
    ret=os.system(hmmcommand)
    if ret==0:
        pass
    else:
        print("Error:ret="+str(ret)+",command="+hmmcommand)
        sys.exit(1)

################################################################################
def getParameters(paraFileName):
    """
    get parameters from config file
    """
    flog=open(LOGFILE,"a")
    flog.write("#"*50+"\n")
    flog.write("#function getParameters start.\n")
    try:
        paraFile=open(paraFileName,"r")
    except IOError as e:
        print("\nERROR: config file not found. Exiting...")
        sys.exit(1)
    para={}
    for line in paraFile:
        if  len(line.strip())==0:
            continue
        if line.strip().startswith('#'):
            continue
        pKey=line.split('=')[0].strip()
        pValue=line.split('=')[1].split('#')[0].strip()
        para[pKey]=pValue
        flog.write("parameter "+pKey+":"+pValue+"\n")
    paraFile.close()
    flog.write("#"*30+"\n")
    flog.close()

    ############################
    #parameter check
    parameters=list(para.keys())
    if "refDBName" not in parameters:   #reference database name
        print("Please check parameter refDBName! Exiting...")
        sys.exit(1)
    if "refMarker" not in parameters:   #input dataset barcode marker, split with '|' when using multiple markers(such as metabarcode or plant reference, like 'refMarker=rbcL|trnL|ITS2')
        print("Please check parameter refMarker! Exiting...")
        sys.exit(1)
    if "refFileName" not in parameters: #input reference dataset file path and name, split with '|' when using multiple markers, refFileName should contains the refMarker 
        print("Please check parameter refFileName! Exiting...")
        sys.exit(1)
    if "Max_length_DNA" not in parameters:  #barcode length check, based on refMarker(working when seqClean=on)
        print("Please check parameter Max_length_DNA! Exiting...")
        sys.exit(1)
    if "Min_length_DNA" not in parameters:  #barcode length check, based on refMarker(working when seqClean=on)
        print("Please check parameter Min_length_DNA! Exiting...")
        sys.exit(1)
    if "roughMaxNum" not in parameters: #max barcodes number from each species to form the rough scan database, based on the reference datasets scale
        print("Please check parameter roughMaxNum! Exiting...")
        sys.exit(1)
    if "roughMinNum" not in parameters: #min threshold for each species, if barcodes number of the species is under this threshold, then barcodes are all been used to form the rough scan database 
        print("Please check parameter roughMinNum! Exiting...")
        sys.exit(1)
    if "roughPercent" not in parameters:    #percent of barcodes to form the rough scan database of each species, all barcode will be used when roughPercent=1
        print("Please check parameter roughPercent! Exiting...")
        sys.exit(1)
    if "deleteRepeatSeq" not in parameters: #reserve only one sequence if barcodes sequences are consistent(off or on), using for large datasets
        print("Please check parameter deleteRepeatSeq! Exiting...")
        sys.exit(1)
    if "estimateFuzzyPara" not in parameters:   #estimate paramater theta1 and theta2 at database construction step(on, default), after ID step(off, for large datasets)
        print("Please check parameter estimateFuzzyPara! Exiting...")
        sys.exit(1)
    if "seqClean" not in parameters:   #replace '-','N' to '', filter out seqequence which length is not in the range setting below (off or on)
        print("Please check parameter seqClean! Exiting...")
        sys.exit(1)
    if para["estimateFuzzyPara"]=="on":
        if "substitutionModel" not in parameters:
            print("Please check parameter substitutionModel! Exiting...")
            sys.exit(1)

    if len(para["refFileName"])==0:
        print("Please check parameter reference dataset file! Exiting...")
        sys.exit(1)

    if len(para["refFileName"].split("|")) != len(para["refMarker"].split("|")):
        print("The number of refMarker and refFile is inconsistent! Exiting...")
        sys.exit(1)

    for refFile in para["refFileName"].split("|"):
        if os.path.exists(refFile):
            pass
        else:
            print("Input reference dataset file:"+refFile+" dose not exist! Exiting...")
            sys.exit(1)
        if ".tsv" in refFile or ".fas" in refFile or ".fasta" in refFile:
            pass
        else:
            print("Please check file Format of reference dataset file:"+refFile+", should be tsv or fasta! Exiting...")
            sys.exit(1)

    if len(para["refMarker"])==0:
        print("Please check parameter refMarker! Exiting...")
        sys.exit(1)
    for refMarker in para["refMarker"].split("|"):
        if refMarker.upper() in para["refFileName"].upper():
            pass
        else:
            print("refMarker:"+refMarker+" should be contained in refFileName! Exiting...")
            sys.exit(1)

    if "refRoughMarker" not in parameters:  #barcode marker using in rough scan step, should be set only applying under plant barcode scenario
        para["refRoughMarker"]=""
    if len(para["refRoughMarker"])==0:
        pass
    else:
        if para["refRoughMarker"].upper() in para["refFileName"].upper():
            pass
        else:
            print("refRoughMarker:"+para["refRoughMarker"]+" should be contained in refFileName! Exiting...")
            sys.exit(1)

    if "refMDMarker" not in parameters: #barcode marker using in MD search step, should be set only applying under plant barcode scenario
        para["refMDMarker"]=""
    if len(para["refMDMarker"])==0:
        pass
    else:
        if para["refMDMarker"].upper() in para["refFileName"].upper():
            pass
        else:
            print("refMDMarker:"+para["refMDMarker"]+" should be contained in refFileName! Exiting...")
            sys.exit(1)

    if (para["refRoughMarker"]=="" and para["refMDMarker"]=="") or (para["refRoughMarker"]!="" and para["refMDMarker"]!=""):
        pass
    else:
        print("refRoughMarker and refMDMarker should be null or with fixed value simultaneously.! Exiting...")
        sys.exit(1)

    try:
        int(para["Max_length_DNA"])
    except:
        print("Please check parameter Max_length_DNA! Exiting...")
        sys.exit(1)
    try:
        int(para["Min_length_DNA"])
    except:
        print("Please check parameter Min_length_DNA! Exiting...")
        sys.exit(1)
    try:
        int(para["roughMaxNum"])
    except:
        print("Please check parameter roughMaxNum, int 1-20! Exiting...")
        sys.exit(1)
    try:
        int(para["roughMinNum"])
    except:
        print("Please check parameter roughMinNum, int 1-5! Exiting...")
        sys.exit(1)
    try:
        float(para["roughPercent"])
    except:
        print("Please check parameter roughPercent, float 0.1-1! Exiting...")
        sys.exit(1)

    if int(para["roughMaxNum"])>0 and int(para["roughMaxNum"])<=20:
        pass
    else:
        print("Please check parameter roughMaxNum, int 1-20! Exiting...")
        sys.exit(1)

    if int(para["roughMinNum"])>0 and int(para["roughMinNum"])<=5:
        pass
    else:
        print("Please check parameter roughMixNum, int 1-5! Exiting...")
        sys.exit(1)

    if float(para["roughPercent"])>0.09 and float(para["roughPercent"])<1.00001:
        pass
    else:
        print("Please check parameter roughPercent, float 0.1-1! Exiting...")
        sys.exit(1)

    if para["deleteRepeatSeq"]=="on" or para["deleteRepeatSeq"]=="off":
        pass
    else:
        print("Please swich deleteRepeatSeq, on(for large datasets) or off(default)! Exiting...")
        sys.exit(1)

    if para["estimateFuzzyPara"]=="on" or para["estimateFuzzyPara"]=="off":
        pass
    else:
        print("Please swich estimateFuzzyPara, on(default) or off(for large datasets)! Exiting...")
        sys.exit(1)

    if para["estimateFuzzyPara"]=="on":
        if para["substitutionModel"]=="K2P" or para["substitutionModel"]=="JC69" or para["substitutionModel"]=="GTR" or para["substitutionModel"]=="P":
            pass
        else:
            print("Please check parameter substitutionModel, (K2P, JC69, GTR, P)! Exiting...")
            sys.exit(1)

    if para["seqClean"]=="on" or para["seqClean"]=="off":
        pass
    else:
        print("Please swich seqClean, on(default) or off! Exiting...")
        sys.exit(1)

    return para

#main###########################################################################
if __name__ == '__main__':
    #main
    flog=open(LOGFILE,"w")
    flog.write("FuzzyID2_makeDB.py: construct FuzzyID2 reference database using local dataset.\n")
    flog.write("Parameters should be checked and adjusted which are reserved in configuration file(such as config.txt).\n")
    flog.write("Any problems, please email me.[zhiyong-shi@163.com]\n")
    flog.close()
    print("FuzzyID2_makeDB.py: construct FuzzyID2 reference database using local dataset.")
    print("Parameters should be checked and adjusted which are reserved in configuration file(such as config.txt).")
    print("Any problems, please email me.[zhiyong-shi@163.com]")
    print("*"*60)

    #process start time
    timeb=time.strftime('%H%M%S', time.localtime(time.time()))
    print("Process start at "+timeb)
    print("-"*60)

    #input
    paraFile=input("Please input config file name:")
    paraList=getParameters(paraFile)#parameters
    print("parameters:")
    print(paraList)
    print("-"*60)

    rmPreDB(paraList)
    for refFile in paraList["refFileName"].split("|"):
        if ".tsv" in refFile:
            print("Processing bold_tsv2fasta start.........")
            tsv2fasta(refFile,paraList)
        seqIdRepeatCheck(refFile)
        seqInOne(refFile)
        print("Processing fasta2db start.........")
        if paraList["deleteRepeatSeq"]=="on":
            deleteRepeatSeq(refFile)
        fasta2db(refFile,paraList)
        if len(paraList["refRoughMarker"])==0:
            continue
    createDBIndex(paraList)
    print("Processing makeHmmDB start........")
    if len(paraList["refRoughMarker"])==0:
        for refMarker in paraList["refMarker"].split("|"):
            makeHmmDB(paraList,refMarker)
    else:
        makeHmmDB(paraList,paraList["refRoughMarker"])
    HmmDBPress(paraList)

    if paraList["estimateFuzzyPara"]=="on":
        markers=""
        if len(paraList["refMDMarker"])==0:
            markers=paraList["refMarker"]
        else:
            markers=paraList["refMDMarker"]
        for MDMarker in markers.split("|"):
            command="./FuzzyID2 -c Theta1 -m "+ paraList["substitutionModel"] +" -d "+paraList["refDBName"]+" -mb "+MDMarker.upper()
            ret=os.system(command)
            if ret==0:
                pass
            else:
                print("Error:ret="+str(ret)+",command="+command)
                sys.exit(1)
            command="mv log Theta1.log"
            ret=os.system(command)
            if ret==0:
                pass
            else:
                print("Error:ret="+str(ret)+",command="+command)
                sys.exit(1)
            
            command="./FuzzyID2 -c Theta2 -m "+ paraList["substitutionModel"] +" -d "+paraList["refDBName"]+" -mb "+MDMarker.upper()
            ret=os.system(command)
            if ret==0:
                pass
            else:
                print("Error:ret="+str(ret)+",command="+command)
                sys.exit(1)
            command="mv log Theta2.log"
            ret=os.system(command)
            if ret==0:
                pass
            else:
                print("Error:ret="+str(ret)+",command="+command)
                sys.exit(1)

    #process end time
    print("-"*60)
    timee=time.strftime('%H%M%S', time.localtime(time.time()))
    print("Process end at "+timee)
