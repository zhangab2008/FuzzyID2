#include "main.h"

void ID(InData *optIn)
{
    Fasta fasReader;
    VectorSequenceContainer *roughQuerySeqs;
    VectorSequenceContainer *MDQuerySeqs;
    int processFlag;

    if(strcmp(optIn->roughBarcode, "")==0){//no rb and mb parameters
        processFlag=0;
        try {
            roughQuerySeqs = fasReader.readSequences(optIn->inFile, &AlphabetTools::DNA_ALPHABET);
        }catch(exception& e){
            cout<<"Please check sequence DNA alphabet! Exit..."<<endl;
            cout<<e.what()<<endl;
            exit(EXIT_FAILURE);
        }
    }else{
        processFlag=1;
        //read the query sequences
        char *myArray[2];
        char inFileName[100];
        memset(myArray, 0x0, sizeof(myArray));
        strcpy(inFileName , optIn->inFile);
        cout<<"in file:"<<inFileName<<endl;
        split(myArray, inFileName, "+");
        for(int i=0;i<2;i++)
        {
            if(myArray[i]!='\0'){
                string inFile=myArray[i];
                if(findIgnoreCase(myArray[i],optIn->roughBarcode)!=std::string::npos){
                    try {
                        roughQuerySeqs = fasReader.readSequences(inFile, &AlphabetTools::DNA_ALPHABET);
                    }catch(exception& e){
                        cout<<"Please check sequence DNA alphabet! Exit..."<<endl;
                        cout<<e.what()<<endl;
                        exit(EXIT_FAILURE);
                    }
                }
                if(findIgnoreCase(myArray[i],optIn->mdBarcode)!=std::string::npos){
                    try {
                        MDQuerySeqs = fasReader.readSequences(inFile, &AlphabetTools::DNA_ALPHABET);
                    }catch(exception& e){
                        cout<<"Please check sequence DNA alphabet! Exit..."<<endl;
                        cout<<e.what()<<endl;
                        exit(EXIT_FAILURE);
                    }
                    //cout<<"md seq ok!"<<endl;
                }
            }
        }
        if(roughQuerySeqs->getNumberOfSequences()==0){
            cout<<"Rough marker query seqFile has 0 sequence! Exit..."<<endl;
            exit(EXIT_FAILURE);
        }
        if(MDQuerySeqs->getNumberOfSequences()==0){
            cout<<"MD marker query seqFile has 0 sequence! Exit..."<<endl;
            exit(EXIT_FAILURE);
        }
        if(roughQuerySeqs->getNumberOfSequences()!=MDQuerySeqs->getNumberOfSequences()){
            cout<<"sequence number is inconsistent in roughBarcode and mdBarcode! Exit..."<<endl;
            exit(EXIT_FAILURE);
        }
    }

    int querySequenceNum = roughQuerySeqs->getNumberOfSequences();
    logFile << "The query file has " << querySequenceNum << " sequences!" << endl;

    for(int i=0;i<querySequenceNum;i++)
    {
        #ifdef DEBUG
        cout<<"start rough loop. seq:"<<roughQuerySeqs->getSequence(i).getName()<<endl;
        #endif
        int flag=0;
        mdResult *mdr;
        mdr = (mdResult *)malloc(sizeof(mdResult));

        string seqName(roughQuerySeqs->getSequence(i).getName());
        outFile << trim(seqName);
        logFile << roughQuerySeqs->getSequence(i).getName() << endl;
        if(roughQuerySeqs->getSequence(i).toString().length()==0)
        {
            outFile << "\t No sequence!" << endl;
            continue;
        }
        Sequence *seqRoughQuery = new BasicSequence(roughQuerySeqs->getName(i),roughQuerySeqs->getSequence(i).toString(),&AlphabetTools::DNA_ALPHABET);

        //calculate order,family,genus,species MD and get the theta1,theta2

        sprintf(mdr->model,"%s",optIn->model);
        sprintf(mdr->dataBase,"%s",optIn->dataBase);
        sprintf(mdr->roughBarcode,"%s",optIn->roughBarcode);
        sprintf(mdr->mdBarcode,"%s",optIn->mdBarcode);

        flag=roughGenus(seqRoughQuery, mdr);
        if (flag==1)
        {
            outFile << "\t The query sequence is too far from the reference dataset!" << endl;
            continue;
        }

        string roughResultList="";
        for(int j=0;j<3;j++){
            #ifdef DEBUG
            cout<<"roughResultList:"<<roughResultList<<endl;
            cout<<"roughResult:"<<mdr->roughResult[j]<<endl;
            #endif
            if (mdr->roughResult[j][0]=='\0')
            {
                break;
            }
            if(roughResultList.find(mdr->roughResult[j])!=std::string::npos){
                continue;
            }else{
                string roughResultStr=mdr->roughResult[j];
                roughResultList=roughResultList+roughResultStr;
            }

            //get rough genusName
            char *myArrayTaxo[3];
            char tmpChar[100];
            memset(myArrayTaxo, 0x0, sizeof(myArrayTaxo));
            sprintf(tmpChar,"%s",mdr->roughResult[j]);
            split(myArrayTaxo, tmpChar, "_");
            sprintf(mdr->roughFamily,"%s",myArrayTaxo[0]);
            sprintf(mdr->roughGenus,"%s",myArrayTaxo[1]);
            if(processFlag==0){
                sprintf(mdr->roughBarcode,"%s",myArrayTaxo[2]);
                sprintf(mdr->mdBarcode,"%s",myArrayTaxo[2]);
            }else{
                if(strcmp(myArrayTaxo[2], mdr->roughBarcode)!=0){
                    outFile << "\t" <<"Rough Family:" << mdr->roughFamily;
                    outFile << "\t" <<"Rough Genus:" << mdr->roughGenus;
                    outFile << "\t" <<"marker is inconsistent between input roughBarcode:"<<mdr->roughBarcode<<" and roughResult marker:"<<myArrayTaxo[2]<<". Exit..." << endl;
                    continue;
                }
            }

            if(strcmp(mdr->roughFamily, "(null)")==0 or strcmp(mdr->roughGenus, "(null)")==0){
                continue;
            }
            logFile<<"    Rough Family:"<<mdr->roughFamily<<endl;
            logFile<<"    Rough genus:"<<mdr->roughGenus<<endl;

            flag=0;
            if(processFlag==0){
                flag = getMD(seqRoughQuery, mdr);

            }else{
                Sequence *seqMDQuery;
                try {
                    seqMDQuery = new BasicSequence(roughQuerySeqs->getName(i),MDQuerySeqs->getSequence(roughQuerySeqs->getName(i)).toString(),&AlphabetTools::DNA_ALPHABET);
                }catch(exception& e){
                    cout<<"SeqID:"<<roughQuerySeqs->getName(i)<<" is not contained in MDQuerySeqs! Exit..."<<endl;
                    outFile<<"\tSeqID:"<<roughQuerySeqs->getName(i)<<" is not contained in MDQuerySeqs! Exit..."<<endl;
                    continue;
                }
                flag = getMD(seqMDQuery, mdr);
            }
            #ifdef DEBUG
            cout<<"getMD flag:"<<flag<<endl;
            cout<<"mdr->taxoName:"<<mdr->taxoName<<endl;
            cout<<"mdr->theta1:"<<mdr->theta1<<endl;
            cout<<"mdr->theta2:"<<mdr->theta2<<endl;
            #endif

            if(flag == 1)//doesn't found the MD sequence
            {
                outFile << "\t" << mdr->roughGenus << " No appropriate species data in the reference dataset!" << endl;
                continue;
            }
            if(mdr->theta1==3.0 or mdr->theta1==2.0){
                outFile << "\t" << mdr->taxoName;
                outFile << "\t" <<"MD:" << mdr->md;
                outFile << "\t" <<"This species has only one sequence in the reference dataset, no theta1." << endl;
            } else if(mdr->theta2==4.0){
                outFile << "\t" << mdr->taxoName;
                outFile << "\t" <<"MD:" << mdr->md;
                outFile << "\t" <<"This genus has only one species in the reference dataset, no theta2." << endl;
            }else{
                //get FMF score
                outFile << "\t" << mdr->taxoName;
                outFile << "\t" <<"FMF:" << calMF(mdr->md,mdr->theta1,mdr->theta2);
                outFile << "\t" <<"MD:" << mdr->md;
                outFile << "\t" <<"Theta1:" << mdr->theta1;
                outFile << "\t" <<"Theta2:" << mdr->theta2 << endl;
            }
            #ifdef DEBUG
            cout<<"end rough loop. seq:"<<roughQuerySeqs->getSequence(i).getName()<<endl;
            #endif
        }
    }//for,loop query sequences
}

//Theta1
void Theta1(InData *optIn)
{
    theta1Result *t1r;
    t1r = (theta1Result *)malloc(sizeof(theta1Result));

    logFile << "getTheta1function start " << endl;
    //get the sequences existing in db
	sprintf(t1r->model,"%s",optIn->model);
	sprintf(t1r->mdBarcode,"%s",optIn->mdBarcode);
    getTheta1function(t1r);
}

//Theta2
void Theta2(InData *optIn)
{
    theta2Result *t2r;
    t2r = (theta2Result *)malloc(sizeof(theta2Result));
    logFile << "getTheta2function start " << endl;

    //get the sequences existing in db
	sprintf(t2r->model,"%s",optIn->model);
	sprintf(t2r->mdBarcode,"%s",optIn->mdBarcode);
    int flag = getTheta2function(t2r);
}
