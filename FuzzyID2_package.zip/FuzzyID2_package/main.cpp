#include "main.h"

ofstream logFile;
ofstream outFile;
sqlite3 *conn=NULL;
char *dbErrMsg=NULL;
char dbName[100];

int main(int argc, char *argv[])
{
    InData *optIn;
    optIn = (InData *)malloc(sizeof(InData));

    init(argc, argv, optIn);
    sprintf(dbName,"./DB/%s",optIn->dataBase);
    logFile << "option check pass" << endl;

    if(strcmp(optIn->command, "ID")==0)
    {
        logFile << "Function ID start" << endl;
        ID(optIn);
        logFile << "Function ID end" << endl;
    }
    else if(strcmp(optIn->command, "Theta1")==0)
    {
        logFile << "Function Theta1 start" << endl;
        Theta1(optIn);
        logFile << "Function Theta1 end" << endl;
    }
    else if(strcmp(optIn->command, "Theta2")==0)
    {
        logFile << "Function Theta2 start" << endl;
        Theta2(optIn);
        logFile << "Function Theta2 end" << endl;
    }
    //close files
	logFile.close();
	outFile.close();
    closeDB();
    return 0;
}

